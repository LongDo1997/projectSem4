package com.aptech.iceCream.config.security;

public class SecurityConstant {
	public static final long JWT_EXPIRATION = 70000;
}