import 'package:flutter/material.dart';

void main() => runApp(const FlowerApp());
const ink = Color(0xff28382c);
const pink = Color(0xffb47882);
const paper = Color(0xfff6f1ed);

class Flower {
  final String name, category;
  final int image, price;
  const Flower(this.name, this.image, this.price, this.category);
  String get photo => 'assets/images/shop-img-$image.jpg';
}

const flowers = [
  Flower('Blush Garden', 13, 690000, 'Bó hoa'),
  Flower('Autumn Dream', 15, 750000, 'Bó hoa'),
  Flower('Blooming Joy', 16, 590000, 'Giỏ hoa'),
  Flower('Forest Bush', 18, 850000, 'Giỏ hoa'),
  Flower('Pearl Roses', 1, 650000, 'Bó hoa'),
  Flower('Pink Harmony', 2, 790000, 'Bó hoa'),
  Flower('Boho Basket', 17, 950000, 'Giỏ hoa'),
  Flower('Sweet Blossom', 3, 550000, 'Bó hoa'),
  Flower('White Elegance', 4, 890000, 'Hoa cưới'),
  Flower('Summer Muse', 5, 620000, 'Bó hoa'),
  Flower('Velvet Romance', 6, 990000, 'Hoa cưới'),
  Flower('Morning Dew', 7, 580000, 'Giỏ hoa'),
];
String money(int value) =>
    '${value.toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')} ₫';

class FlowerApp extends StatelessWidget {
  const FlowerApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Rosebud Flower Studio',
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: Colors.white,
      colorScheme: ColorScheme.fromSeed(
        seedColor: ink,
        primary: ink,
        secondary: pink,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        foregroundColor: ink,
        centerTitle: true,
      ),
      inputDecorationTheme: const InputDecorationTheme(
        border: OutlineInputBorder(),
        filled: true,
        fillColor: paper,
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 18),
          shape: const RoundedRectangleBorder(),
        ),
      ),
    ),
    home: const Shop(),
  );
}

class Shop extends StatefulWidget {
  const Shop({super.key});
  @override
  State<Shop> createState() => _ShopState();
}

class _ShopState extends State<Shop> {
  int tab = 0;
  String query = '', category = 'Tất cả', sorting = 'Mặc định';
  final Map<Flower, int> cart = {};
  int get count => cart.values.fold(0, (a, b) => a + b);
  int get total => cart.entries.fold(0, (a, e) => a + e.key.price * e.value);
  void add(Flower p, [int quantity = 1]) {
    setState(() => cart[p] = ((cart[p] ?? 0) + quantity).clamp(1, 99));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Đã thêm ${p.name} vào giỏ'),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  Widget heading(String text, [double size = 30]) => Text(
    text,
    style: TextStyle(
      fontFamily: 'Georgia',
      fontSize: size,
      color: ink,
      height: 1.2,
    ),
  );
  Widget sectionTitle(String tag, String title) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 28),
    child: Column(
      children: [
        Text(
          tag.toUpperCase(),
          style: const TextStyle(color: pink, letterSpacing: 2, fontSize: 11),
        ),
        const SizedBox(height: 10),
        heading(title),
      ],
    ),
  );
  Widget grid(List<Flower> items) => LayoutBuilder(
    builder: (context, box) {
      final columns = box.maxWidth > 850
          ? 4
          : box.maxWidth > 580
          ? 3
          : 2;
      return GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: items.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: columns,
          crossAxisSpacing: 16,
          mainAxisSpacing: 20,
          mainAxisExtent: box.maxWidth / columns * 1.22 + 122,
        ),
        itemBuilder: (context, i) {
          final p = items[i];
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                child: InkWell(
                  onTap: () => detail(p),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.asset(p.photo, fit: BoxFit.cover),
                      if (p == flowers.first)
                        const Positioned(
                          top: 10,
                          left: 8,
                          child: ColoredBox(
                            color: Colors.white,
                            child: Padding(
                              padding: EdgeInsets.all(7),
                              child: Text(
                                'YÊU THÍCH',
                                style: TextStyle(fontSize: 9, letterSpacing: 1),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                p.name,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontFamily: 'Georgia',
                  fontSize: 18,
                  color: ink,
                ),
              ),
              Text(
                money(p.price),
                textAlign: TextAlign.center,
                style: const TextStyle(color: pink),
              ),
              TextButton(
                onPressed: () => add(p),
                child: const Text(
                  'THÊM VÀO GIỎ +',
                  style: TextStyle(fontSize: 11, letterSpacing: 1),
                ),
              ),
            ],
          );
        },
      );
    },
  );
  Widget home() => Column(
    children: [
      Container(
        color: paper,
        child: LayoutBuilder(
          builder: (context, box) {
            final image = Image.asset(
              'assets/images/h1-img-1.jpg',
              height: box.maxWidth > 700 ? 470 : 280,
              width: double.infinity,
              fit: BoxFit.cover,
            );
            final copy = Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'ROSEBUD · FLOWERS & FEELINGS',
                    style: TextStyle(
                      fontSize: 11,
                      letterSpacing: 2,
                      color: pink,
                    ),
                  ),
                  const SizedBox(height: 20),
                  heading('Để hoa nói\nlời yêu thương.', 44),
                  const SizedBox(height: 18),
                  const Text(
                    'Một bó hoa, ngàn cảm xúc. Gửi chút dịu dàng đến người bạn yêu thương.',
                    style: TextStyle(height: 1.8, color: Colors.black54),
                  ),
                  const SizedBox(height: 24),
                  FilledButton(
                    onPressed: () => setState(() => tab = 1),
                    child: const Text('KHÁM PHÁ BỘ SƯU TẬP'),
                  ),
                ],
              ),
            );
            return box.maxWidth > 700
                ? Row(
                    children: [
                      Expanded(child: copy),
                      Expanded(child: image),
                    ],
                  )
                : Column(children: [image, copy]);
          },
        ),
      ),
      Padding(
        padding: const EdgeInsets.all(24),
        child: Wrap(
          spacing: 40,
          runSpacing: 20,
          children: [
            for (final (icon, label) in [
              (Icons.spa_outlined, 'Hoa tươi chọn lọc'),
              (Icons.card_giftcard, 'Gói trọn yêu thương'),
              (Icons.favorite_border, 'Cho mọi dịp đặc biệt'),
            ])
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, color: pink),
                  const SizedBox(width: 10),
                  Text(label),
                ],
              ),
          ],
        ),
      ),
      sectionTitle('Được làm bằng tình yêu', 'Những đóa hoa được yêu thích'),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: grid(flowers.take(4).toList()),
      ),
      Padding(
        padding: const EdgeInsets.all(24),
        child: OutlinedButton(
          onPressed: () => setState(() => tab = 1),
          child: const Text('XEM TẤT CẢ SẢN PHẨM'),
        ),
      ),
      Container(
        width: double.infinity,
        color: paper,
        padding: const EdgeInsets.all(32),
        child: Column(
          children: [
            sectionTitle('Câu chuyện Rosebud', 'Nơi khoảnh khắc đẹp bắt đầu'),
            const Text(
              'Mỗi bông hoa là một câu chuyện. Chúng tôi kết hợp màu sắc tự nhiên và sự chăm chút để gửi gắm những tình cảm bạn muốn trao.',
              textAlign: TextAlign.center,
              style: TextStyle(height: 1.8),
            ),
            const SizedBox(height: 24),
            Image.asset(
              'assets/images/h2-img-1.jpg',
              height: 250,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ],
        ),
      ),
    ],
  );
  Widget collection() {
    final items = flowers
        .where(
          (p) =>
              (category == 'Tất cả' || p.category == category) &&
              p.name.toLowerCase().contains(query.toLowerCase()),
        )
        .toList();
    if (sorting == 'Giá tăng dần') {
      items.sort((a, b) => a.price.compareTo(b.price));
    }
    if (sorting == 'Giá giảm dần') {
      items.sort((a, b) => b.price.compareTo(a.price));
    }
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          sectionTitle('Tươi mới mỗi ngày', 'Bộ sưu tập hoa'),
          TextField(
            onChanged: (value) => setState(() => query = value),
            decoration: const InputDecoration(
              hintText: 'Tìm tên hoa...',
              prefixIcon: Icon(Icons.search),
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            children: [
              for (final c in ['Tất cả', 'Bó hoa', 'Giỏ hoa', 'Hoa cưới'])
                ChoiceChip(
                  label: Text(c),
                  selected: category == c,
                  onSelected: (_) => setState(() => category = c),
                ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('${items.length} sản phẩm'),
              DropdownButton<String>(
                value: sorting,
                items: ['Mặc định', 'Giá tăng dần', 'Giá giảm dần']
                    .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                    .toList(),
                onChanged: (s) => setState(() => sorting = s!),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (items.isEmpty)
            const Padding(
              padding: EdgeInsets.all(32),
              child: Text(
                'Không tìm thấy sản phẩm. Hãy thử tên khác.',
                textAlign: TextAlign.center,
              ),
            )
          else
            grid(items),
        ],
      ),
    );
  }

  void detail(Flower p) {
    int quantity = 1, selectedImage = 0;
    final images = [
      p.photo,
      if (p.image != 3)
        for (int i = 1; i <= 4; i++)
          'assets/images/shop-img-${p.image}-gallery-img-$i.jpg',
    ];
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (context) => StatefulBuilder(
          builder: (context, update) => Scaffold(
            appBar: AppBar(title: const Text('Chi tiết sản phẩm')),
            body: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 700),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Image.asset(
                        images[selectedImage],
                        height: 360,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        children: [
                          for (int i = 0; i < images.length; i++)
                            InkWell(
                              onTap: () => update(() => selectedImage = i),
                              child: Container(
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: selectedImage == i ? pink : paper,
                                    width: 2,
                                  ),
                                ),
                                child: Image.asset(
                                  images[i],
                                  width: 56,
                                  height: 65,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 24),
                      heading(p.name, 36),
                      Text(
                        money(p.price),
                        style: const TextStyle(color: pink, fontSize: 24),
                      ),
                      const SizedBox(height: 18),
                      const Text(
                        'Hoa tươi được lựa chọn cẩn thận, phối màu tinh tế và gói bằng tất cả sự chăm chút. Món quà dịu dàng cho những khoảnh khắc đáng nhớ.',
                        style: TextStyle(height: 1.8),
                      ),
                      const SizedBox(height: 16),
                      Text('Danh mục: ${p.category}'),
                      Row(
                        children: [
                          IconButton(
                            onPressed: quantity > 1
                                ? () => update(() => quantity--)
                                : null,
                            icon: const Icon(Icons.remove),
                          ),
                          Text('$quantity'),
                          IconButton(
                            onPressed: quantity < 99
                                ? () => update(() => quantity++)
                                : null,
                            icon: const Icon(Icons.add),
                          ),
                          const Spacer(),
                          FilledButton(
                            onPressed: () {
                              add(p, quantity);
                              Navigator.pop(context);
                            },
                            child: const Text('THÊM VÀO GIỎ'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        'Hình ảnh minh họa. Thành phần hoa có thể thay đổi theo mùa.',
                        style: TextStyle(color: Colors.black54),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget basket() => Padding(
    padding: const EdgeInsets.all(20),
    child: Column(
      children: [
        sectionTitle('Gửi một chút yêu thương', 'Giỏ hàng của bạn'),
        if (cart.isEmpty) ...[
          const Icon(Icons.shopping_bag_outlined, size: 70, color: pink),
          const Padding(
            padding: EdgeInsets.all(24),
            child: Text('Giỏ hàng đang trống.'),
          ),
          FilledButton(
            onPressed: () => setState(() => tab = 1),
            child: const Text('CHỌN HOA'),
          ),
        ] else ...[
          for (final entry in cart.entries)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Row(
                children: [
                  InkWell(
                    onTap: () => detail(entry.key),
                    child: Image.asset(
                      entry.key.photo,
                      width: 72,
                      height: 90,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          entry.key.name,
                          style: const TextStyle(
                            fontFamily: 'Georgia',
                            fontSize: 18,
                          ),
                        ),
                        Text(
                          money(entry.key.price),
                          style: const TextStyle(color: pink),
                        ),
                        Row(
                          children: [
                            IconButton(
                              onPressed: entry.value > 1
                                  ? () => setState(
                                      () => cart[entry.key] = entry.value - 1,
                                    )
                                  : null,
                              icon: const Icon(Icons.remove, size: 18),
                            ),
                            Text('${entry.value}'),
                            IconButton(
                              onPressed: entry.value < 99
                                  ? () => setState(
                                      () => cart[entry.key] = entry.value + 1,
                                    )
                                  : null,
                              icon: const Icon(Icons.add, size: 18),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => setState(() => cart.remove(entry.key)),
                    icon: const Icon(Icons.delete_outline),
                  ),
                ],
              ),
            ),
          const Divider(),
          summary('Tạm tính', money(total)),
          summary('Giao hàng', 'Miễn phí (demo)'),
          summary('Tổng cộng', money(total)),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: checkout,
              child: const Text('TIẾN HÀNH ĐẶT HÀNG'),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Giỏ hàng được lưu trong phiên chạy ứng dụng.',
            style: TextStyle(color: Colors.black54, fontSize: 12),
          ),
        ],
      ],
    ),
  );
  Widget summary(String name, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 12),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(name),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
      ],
    ),
  );
  void checkout() {
    final key = GlobalKey<FormState>();
    String payment = 'Thanh toán khi nhận hàng';
    Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (context) => StatefulBuilder(
          builder: (context, update) => Scaffold(
            appBar: AppBar(title: const Text('Thông tin đặt hàng')),
            body: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 600),
                  child: Form(
                    key: key,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        heading('Gửi hoa đến người thương'),
                        const SizedBox(height: 24),
                        for (final label in [
                          'Họ và tên',
                          'Số điện thoại',
                          'Địa chỉ nhận hoa',
                        ])
                          Padding(
                            padding: const EdgeInsets.only(bottom: 18),
                            child: TextFormField(
                              keyboardType: label == 'Số điện thoại'
                                  ? TextInputType.phone
                                  : TextInputType.text,
                              decoration: InputDecoration(labelText: label),
                              validator: (value) {
                                if (value == null || value.trim().isEmpty) {
                                  return 'Vui lòng nhập $label';
                                }
                                if (label == 'Số điện thoại' &&
                                    !RegExp(
                                      r'^\+?[0-9\s.-]{9,15}$',
                                    ).hasMatch(value.trim())) {
                                  return 'Số điện thoại chưa hợp lệ';
                                }
                                return null;
                              },
                            ),
                          ),
                        const TextField(
                          maxLines: 3,
                          decoration: InputDecoration(
                            labelText: 'Lời nhắn trên thiệp (tùy chọn)',
                          ),
                        ),
                        const SizedBox(height: 20),
                        DropdownButtonFormField<String>(
                          initialValue: payment,
                          decoration: const InputDecoration(
                            labelText: 'Phương thức thanh toán',
                          ),
                          items:
                              [
                                    'Thanh toán khi nhận hàng',
                                    'Chuyển khoản (demo)',
                                  ]
                                  .map(
                                    (s) => DropdownMenuItem(
                                      value: s,
                                      child: Text(s),
                                    ),
                                  )
                                  .toList(),
                          onChanged: (s) => update(() => payment = s!),
                        ),
                        const SizedBox(height: 20),
                        for (final e in cart.entries)
                          summary(
                            '${e.key.name} × ${e.value}',
                            money(e.key.price * e.value),
                          ),
                        summary('Tổng cộng', money(total)),
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 16),
                          child: Text(
                            'Đây là đơn hàng thử nghiệm. Không phát sinh thanh toán, không gửi thông tin đến cửa hàng.',
                            style: TextStyle(color: pink),
                          ),
                        ),
                        FilledButton(
                          onPressed: () async {
                            if (!key.currentState!.validate()) return;
                            await showDialog<void>(
                              context: context,
                              barrierDismissible: false,
                              builder: (dialogContext) => AlertDialog(
                                title: const Text('Đã tạo đơn hàng mẫu'),
                                content: const Text(
                                  'Cảm ơn bạn đã chọn Rosebud! Đây là xác nhận demo, cửa hàng chưa nhận được đơn hàng.',
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () =>
                                        Navigator.pop(dialogContext),
                                    child: const Text('HOÀN TẤT'),
                                  ),
                                ],
                              ),
                            );
                            if (!context.mounted) return;
                            setState(() {
                              cart.clear();
                              tab = 0;
                            });
                            Navigator.pop(context);
                          },
                          child: const Text('XÁC NHẬN ĐƠN HÀNG MẪU'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      toolbarHeight: 78,
      title: const Column(
        children: [
          Text(
            'ROSEBUD',
            style: TextStyle(
              fontFamily: 'Georgia',
              letterSpacing: 5,
              fontSize: 26,
            ),
          ),
          Text(
            'FLOWER STUDIO',
            style: TextStyle(fontSize: 9, letterSpacing: 3, color: pink),
          ),
        ],
      ),
      actions: [
        IconButton(
          tooltip: 'Giỏ hàng',
          onPressed: () => setState(() => tab = 2),
          icon: Badge(
            label: Text('$count'),
            isLabelVisible: count > 0,
            child: const Icon(Icons.shopping_bag_outlined),
          ),
        ),
        const SizedBox(width: 12),
      ],
    ),
    body: SingleChildScrollView(
      key: ValueKey(tab),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1200),
          child: Column(
            children: [
              if (tab == 0)
                home()
              else if (tab == 1)
                collection()
              else
                basket(),
              const SizedBox(height: 36),
              Container(
                width: double.infinity,
                color: ink,
                padding: const EdgeInsets.all(32),
                child: const Column(
                  children: [
                    Text(
                      'ROSEBUD',
                      style: TextStyle(
                        fontFamily: 'Georgia',
                        color: Colors.white,
                        letterSpacing: 4,
                        fontSize: 24,
                      ),
                    ),
                    SizedBox(height: 12),
                    Text(
                      'Một chút dịu dàng từ thiên nhiên.\nHoa tươi cho những điều bạn muốn nói.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white70, height: 1.8),
                    ),
                    SizedBox(height: 18),
                    Text(
                      'Ứng dụng cửa hàng hoa · Bản demo',
                      style: TextStyle(color: Colors.white54, fontSize: 11),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ),
    bottomNavigationBar: NavigationBar(
      selectedIndex: tab,
      onDestinationSelected: (value) => setState(() => tab = value),
      destinations: const [
        NavigationDestination(
          icon: Icon(Icons.home_outlined),
          label: 'Trang chủ',
        ),
        NavigationDestination(
          icon: Icon(Icons.local_florist_outlined),
          label: 'Bộ sưu tập',
        ),
        NavigationDestination(
          icon: Icon(Icons.shopping_bag_outlined),
          label: 'Giỏ hàng',
        ),
      ],
    ),
  );
}
