package com.aptech.iceCream.repositories;

import com.aptech.iceCream.dto.ImageDTO.ImageSearchReqDTO;
import com.aptech.iceCream.dto.ImageDTO.ImageSearchResultDTO;
import com.aptech.iceCream.dto.ImageDTO.ImageUploadedDTO;

import java.util.List;
import org.springframework.data.jpa.repository.Query;

public interface ImageRepository {

//	@Query( value="Select I.Id"
//    		+ "			  ,I.FileName"
//    		+ "			  ,I.FilePath"
//    		+ "			  ,I.OrgFileName"
//    		+ "			  ,I.orderNum"
//    		+ "			  ,I.CreatedAt"
//    		+ "			  ,I.UpdatedAt"
//    		+ "			  ,I.UserCreatedId"
//    		+ "			  ,(SELECT Name FROM UserAccount WHERE Id = I.UserCreatedId) AS UserCreated"
//    		+ "			  ,I.UserModifyId"
//    		+ "			  ,(SELECT Name FROM UserAccount WHERE Id = I.UserModifyId) AS UserModified"
//    		+ "		 FROM Image I"
//    		+ "		 WHERE 1=1"
//    		+ "		 AND I.Id IN (:#{#dto.ids})"
//    		+ "		 Order by I.orderNum", nativeQuery = true)
//    List<ImageSearchResultDTO> findImageDTOList(ImageSearchReqDTO dto);
//
//    @Query( value="Select I.Id"
//    		+ "			  ,I.FileName"
//    		+ "			  ,I.FilePath"
//    		+ "			  ,I.OrgFileName"
//    		+ "			  ,I.orderNum"
//    		+ "			  ,I.CreatedAt"
//    		+ "			  ,I.UpdatedAt"
//    		+ "			  ,I.UserCreatedId"
//    		+ "			  ,(SELECT Name FROM UserAccount WHERE Id = I.UserCreatedId) AS UserCreated"
//    		+ "			  ,I.UserModifyId"
//    		+ "			  ,(SELECT Name FROM UserAccount WHERE Id = I.UserModifyId) AS UserModified"
//    		+ "		 FROM Image I"
//    		+ "		 WHERE 1=1"
//    		+ "		 AND CONCAT(I.FilePath,'') = :#{#dto.filePath}"
//    		+ "		 AND I.FileName IN (:#{#dto.fileNames})"
//    		+ "		 Order by I.orderNum", nativeQuery = true)
//    List<ImageSearchResultDTO> findImageDTOListByFileName(ImageUploadedDTO dto);
}
