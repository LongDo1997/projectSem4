import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flower_shop_flutter/main.dart';

void main() {
  test('Catalog preserves original products and VND prices', () {
    expect(flowers.length, 12);
    expect(money(690000), '690.000 ₫');
    expect(flowers.map((p) => p.image).toSet().length, 12);
  });
  testWidgets('Add a flower and change its quantity in cart', (tester) async {
    await tester.pumpWidget(const FlowerApp());
    await tester.tap(find.text('Bộ sưu tập'));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('THÊM VÀO GIỎ +').first);
    await tester.tap(find.text('THÊM VÀO GIỎ +').first);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Giỏ hàng'));
    await tester.pumpAndSettle();
    expect(find.text('Blush Garden'), findsOneWidget);
    expect(find.text('690.000 ₫'), findsNWidgets(3));
    await tester.tap(find.byIcon(Icons.add));
    await tester.pumpAndSettle();
    expect(find.text('1.380.000 ₫'), findsNWidgets(2));
    await tester.ensureVisible(find.text('TIẾN HÀNH ĐẶT HÀNG'));
    await tester.tap(find.text('TIẾN HÀNH ĐẶT HÀNG'));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('XÁC NHẬN ĐƠN HÀNG MẪU'));
    await tester.tap(find.text('XÁC NHẬN ĐƠN HÀNG MẪU'));
    await tester.pumpAndSettle();
    expect(find.text('Vui lòng nhập Họ và tên'), findsOneWidget);
    expect(find.text('Vui lòng nhập Số điện thoại'), findsOneWidget);
  });
}
