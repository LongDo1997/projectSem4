package com.aptech.iceCream.service;

import com.aptech.iceCream.dto.BookDTO;
import com.aptech.iceCream.dto.BookDTO.BookSearchReqDTO;
import com.aptech.iceCream.dto.BookDTO.BookSearchResultDTO;
import com.aptech.iceCream.entities.BookEntity;
import com.aptech.iceCream.utils.ListResponse;

import java.util.List;

public interface ICategoryService {

}
