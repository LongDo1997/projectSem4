﻿# Rosebud Flower Studio — Flutter

Ứng dụng Flutter dựa trên giao diện HTML/CSS/JS và ảnh trong thư mục flower-shop.

## Chạy trong Visual Studio Code
1. Mở thư mục flower_shop_flutter trong VS Code.
2. Cài extension Flutter và Dart khi VS Code đề xuất.
3. Mở terminal và chạy: flutter pub get
4. Nhấn Ctrl+Shift+P → Flutter: Launch Emulator → chọn máy ảo Android.
5. Chọn thiết bị ở thanh trạng thái, nhấn F5 (cấu hình Rosebud Flutter).

Nếu chưa có máy ảo: Android Studio → Device Manager → Create Virtual Device → chọn điện thoại và tải system image → Finish.

Lệnh thay thế:
```
flutter doctor
flutter emulators
flutter emulators --launch <emulator_id>
flutter devices
flutter run -d <device_id>
```
Có thể chạy trên trình duyệt: flutter run -d chrome

## Chức năng
Trang chủ, 12 sản phẩm gốc, tìm tên, lọc danh mục, sắp xếp giá, chi tiết với ảnh gallery, chọn số lượng, giỏ hàng, biểu mẫu người nhận và xác nhận đơn mẫu. Giao diện thích ứng điện thoại và màn hình lớn.

Giỏ hàng chỉ lưu trong bộ nhớ, sẽ mất khi khởi động lại. Chưa có backend, tài khoản, lưu đơn hoặc thanh toán thật. Đơn demo không gửi dữ liệu đi.

## Kiểm tra
```
flutter analyze
flutter test
flutter build web
```

## Cấu hình Android trên máy hiện tại
Dùng Gradle 8.13 và JDK 21 sẵn có. android/gradle.properties có org.gradle.java.home=C:/Users/huent/.jdks/ms-21.0.7; đổi hoặc xóa dòng này khi chuyển sang máy khác.
Máy ảo hiện có: Medium_Phone_API_36.1.
Nếu flutter doctor báo thiếu cmdline-tools: Android Studio → SDK Manager → SDK Tools → Android SDK Command-line Tools (latest) → Apply. Sau đó chạy flutter doctor --android-licenses và tự đọc/chấp nhận giấy phép.

Lần chạy Android đầu tiên đang thiếu NDK 27.0.12077973 và tải tự động chưa hoàn tất. Có thể cài qua Android Studio → SDK Manager → SDK Tools → Show Package Details → NDK (Side by side) → 27.0.12077973 → Apply. Cài xong chạy flutter run -d emulator-5554 (khi máy ảo đang mở).
Đã kiểm tra: flutter analyze không có vấn đề; flutter test đạt 2 bài; flutter build web thành công. Chưa xác nhận build/cài Android thành công do bước tải NDK.
