package com.aptech.iceCream.web.controllers;

import com.aptech.iceCream.dto.BookDTO;
import com.aptech.iceCream.entities.BookEntity;
import com.aptech.iceCream.service.impl.BookService;
import com.aptech.iceCream.utils.Constants;
import com.aptech.iceCream.utils.ListResponse;
import java.awt.print.Book;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping(Constants.REQUEST_MAPPING_PREFIX_WEB + "/book")
public class BookWebController {
//	@Autowired
//	private BookService bookService;
//
//	@GetMapping(value = { "", "/", "/index" })
//	public String index(Model model) {
//		BookDTO.BookSearchReqDTO req = new BookDTO.BookSearchReqDTO();
//		// ListResponse<BookEntity> bookList = bookService.getAll(req);
//
//		// model.addAttribute("books", bookList.getData().getItems());
//
//		return "web/admin/book/index";
//	}
}
