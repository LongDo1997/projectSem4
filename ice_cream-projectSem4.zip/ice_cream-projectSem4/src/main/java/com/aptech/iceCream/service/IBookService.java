package com.aptech.iceCream.service;

import java.util.List;

import com.aptech.iceCream.dto.BookDTO;
import com.aptech.iceCream.dto.BookDTO.BookSearchReqDTO;
import com.aptech.iceCream.dto.BookDTO.BookSearchResultDTO;
import com.aptech.iceCream.entities.BookEntity;
import com.aptech.iceCream.utils.ListResponse;

public interface IBookService {
	ListResponse<BookEntity> getAll(BookDTO req);

	List<BookEntity> getAll();

	ListResponse<BookSearchResultDTO> getAll(BookSearchReqDTO req);
}
