package com.aptech.iceCream.dto;

import java.sql.Clob;
import java.sql.NClob;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.hibernate.annotations.Nationalized;
import org.hibernate.annotations.UpdateTimestamp;

import com.aptech.iceCream.dto.BaseDTO.BaseSearchResultDTO;
import com.aptech.iceCream.entities.ImageEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Value;

public class ImageDTO {

	@Data
	@ToString
	public static class ImageSearchReqDTO extends SimpleRequestDTO {
		private String id;
		private List<String> ids;
		private List<String> fileNames;
		private String filePath;
	}

	@Data
	@ToString
	public static class ImageUploadedDTO {
		private List<ImageEntity> imageEntities;
		private List<String> fileNames;

		@Lob
		private String filePath;
	}

	public interface ImageSearchResultDTO extends BaseSearchResultDTO {
		String getId();

		String getFileName();

		String getFilePath();

		String getOrgFileName();

		Integer getOrderNum();
	}
}
